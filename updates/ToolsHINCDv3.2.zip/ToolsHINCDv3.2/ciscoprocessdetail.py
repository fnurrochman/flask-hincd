import os
import re
import pandas as pd

file_name = 'OutputPM.csv'

from ntc_templates.parse import parse_output

your_path = 'Source Cisco'
files = os.listdir(your_path)
filename = your_path + '/'

start_version_ios = 'Version'
end_version_ios = 'RELEASE SOFTWARE'
start_version_nx9k = 'NXOS: version'
end_version_nx9k = ''
start_version_nx = 'system:    version '
end_version_nx = ''

def search_version_ios():
    find_version_ios = re.search(start_version_ios + '(.*)' + end_version_ios, text)
    if find_version_ios is None:
        version_ios = 'Cant find version ios'
    else:
        version_ios = find_version_ios.group(1)
    return version_ios

def search_version_nx9k():
    find_version_nx9k = re.search(start_version_nx9k + '(.*)' + end_version_nx9k, text)
    if find_version_nx9k is None:
        version_nx9k = 'Cant find version nx9k'
    else:
        version_nx9k = find_version_nx9k.group(1)
    return version_nx9k

def search_version_nx():
    find_version_nx = re.search(start_version_nx + '(.*)' + end_version_nx, text)
    if find_version_nx is None:
        version_nx = 'Cant find version nx'
    else:
        version_nx = find_version_nx.group(1)
    return version_nx

df_list_version_ios = []
df_list_version_nxos = []

def to_doc_ios_version(filename, ios_version):
    df_list_version_ios.append(pd.DataFrame(ios_version))
    writer = pd.ExcelWriter(filename + 'SHOW VERSION IOS.xlsx', engine='xlsxwriter')
    df_version_ios = pd.concat(df_list_version_ios)
    df_version_ios.to_excel(writer, sheet_name='show version ios', index=False, header=True)
    writer.save()

def search_ios_version():
    parsed = parse_output(platform="cisco_ios", command ="show version", data=text)
    return parsed

def search_ios_cdp_neighbors():
    parsed = parse_output(platform="cisco_ios", command ="show cdp neighbors", data=text)
    return parsed

def search_ios_cdp_neighbors_det():
    parsed = parse_output(platform="cisco_ios", command ="show cdp neighbors detail", data=text)
    return parsed

def search_ios_inventory():
    parsed = parse_output(platform="cisco_ios", command ="show inventory", data=text)
    return parsed

def to_doc_nxos_version(filename, nxos_version):
    df_list_version_nxos.append(pd.DataFrame(nxos_version))
    writer = pd.ExcelWriter(filename + 'SHOW VERSION NXOS.xlsx', engine='xlsxwriter')
    df_version_nxos = pd.concat(df_list_version_nxos)
    df_version_nxos.to_excel(writer, sheet_name='show version nxos', index=False, header=True)
    writer.save()

def search_nxos_version():
    parsed = parse_output(platform="cisco_nxos", command ="show version", data=text)
    return parsed

def search_nxos_cdp_neighbors():
    parsed = parse_output(platform="cisco_nxos", command ="show cdp neighbors", data=text)
    return parsed

def search_nxos_cdp_neighbors_det():
    parsed = parse_output(platform="cisco_nxos", command ="show cdp neighbors detail", data=text)
    return parsed


def search_nxos_inventory():
    parsed = parse_output(platform="cisco_nxos", command ="show inventory", data=text)
    return parsed

print("Demi Maintenance HINCD yang lebih baik")

your_path = 'Source Cisco'
files = os.listdir(your_path)
for file in files:
    if os.path.isfile(os.path.join(your_path, file))  and file.endswith('.txt'):
        f = open(os.path.join(your_path, file),'r')
        text = f.read()
        
        print("Processing " + file + " .......")

        hostname = os.path.splitext(file)[0]        
        version_output_ios = search_version_ios()
        version_output_nx9k = search_version_nx9k()
        version_output_nx = search_version_nx()

        if version_output_ios != 'Cant find version ios':
            f_name, f_ext = os.path.splitext(file)

            ios_version = search_ios_version()
            to_doc_ios_version(filename, ios_version)

            ios_cdp_neighbors = search_ios_cdp_neighbors()
            ios_cdp_neighbors_det = search_ios_cdp_neighbors_det()
            ios_inventory = search_ios_inventory()

            writer = pd.ExcelWriter(filename + f_name + '.xlsx', engine='xlsxwriter')
            df_cdp_nei_ios = pd.DataFrame(ios_cdp_neighbors)
            df_cdp_nei_ios.to_excel(writer, sheet_name='CDP NEI', index=False, header=True)
            df_cdp_nei_det_ios = pd.DataFrame(ios_cdp_neighbors_det)
            df_cdp_nei_det_ios.to_excel(writer, sheet_name='CDP NEI DET', index=False, header=True)        
            df_inven_ios = pd.DataFrame(ios_inventory)
            df_inven_ios.to_excel(writer, sheet_name='INVENTORY', index=False, header=True)

            writer.save()
        elif version_output_nx9k != 'Cant find version nx9k' or version_output_nx != 'Cant find version nx':
            f_name, f_ext = os.path.splitext(file)

            nxos_version = search_nxos_version()
            to_doc_nxos_version(filename, nxos_version)

            nxos_cdp_neighbors = search_nxos_cdp_neighbors()
            nxos_cdp_neighbors_det = search_nxos_cdp_neighbors_det()
            nxos_inventory = search_nxos_inventory()

            writer = pd.ExcelWriter(filename + f_name + '.xlsx', engine='xlsxwriter')
            df_cdp_nei_nxos = pd.DataFrame(nxos_cdp_neighbors)
            df_cdp_nei_nxos.to_excel(writer, sheet_name='CDP NEI', index=False, header=True)
            df_cdp_nei_det_nxos = pd.DataFrame(nxos_cdp_neighbors_det)
            df_cdp_nei_det_nxos.to_excel(writer, sheet_name='CDP NEI DET', index=False, header=True)        
            df_inven_nxos = pd.DataFrame(nxos_inventory)
            df_inven_nxos.to_excel(writer, sheet_name='INVENTORY', index=False, header=True)

            writer.save()
        else:
            print("Version Tidak Ditemukan")

        f.close()