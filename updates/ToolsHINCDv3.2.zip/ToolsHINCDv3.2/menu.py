import os
import sys
currentFolder = os.path.abspath(os.path.dirname(__file__))
env_folder = os.path.abspath(os.path.join(currentFolder, "env"))
sys.path.insert(0, env_folder)
from env import getVersion, functiontools
menu_options = {
    1: 'Collect File Cisco',
    2: 'Process Log File Cisco ( Default )',
    3: 'Process Log File Cisco ( Detail )',
    9: 'Installer ( One Time Only )',
    0: 'Exit',
}

def print_menu():
    print ("Demi Maintenance HINCD yang lebih baik")
    for key in menu_options.keys():
        print (key, '--', menu_options[key] )

def option1():
    import ciscocollect

def option2():
    import ciscoprocessdefault

def option3():
    import ciscoprocessdetail
def option9():
    import installer

if __name__=='__main__':
    while(True):


        banner = '\nTools HINCD Version {} for {}'.format(getVersion(),functiontools())
        print(banner)
        print_menu()
        option = ''
        try:
            option = int(input('Enter your choice: '))
        except:
            print('Wrong input. Please enter a number ...')
        #Check what choice was entered and act accordingly
        if option == 1:
           option1()
        elif option == 2:
            option2()
        elif option == 3:
            option3()
        elif option == 9:
            option9()
        elif option == 0:
            print('Thank you')
            exit()
        else:
            print('Invalid option. Please enter a number between 1 and 5.')