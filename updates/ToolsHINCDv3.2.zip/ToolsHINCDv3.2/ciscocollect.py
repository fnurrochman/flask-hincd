#testing with parse command from input
import csv
from netmiko import ConnectHandler


sourcedev = input("File Perangkat : ")
sourcecmd = input("File Command   : ")
def to_doc(file, payload):
    f = open('Source Cisco/', file, 'w')
    f.write('\n')
    f.write(str("".join(payload)))
    #f.write(str(payload))
    f.write('\n')
    f.close()

with open(sourcedev) as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    next(csv_reader, None)
    for row in csv_reader:
        hostname = row[1]
        if (row[0] == "ssh"):
            if (row[5] == "no"):
                devices = {
                    'device_type': 'cisco_ios',
                    'ip': row[2],
                    'username': row[3],
                    'password': row[4],
                    'fast_cli': False,
                }
                try:
                    net_connect = ConnectHandler(**devices)

                    hostname = row[1]

                    print("Processing " + hostname + " .......")
                    with open(sourcecmd, 'r') as file:
                        y = []
                        line = file.readlines()
                        for lines in line:
                            try:
                                send = net_connect.send_command(lines, delay_factor=2)
                                newlines = lines.strip('\n')
                                output = hostname + '# '+ lines + '\n' + send + '\n'
                                y.append(output)
                                print("Successfully execute command " + newlines + " in " + hostname)
                            except Exception as e:
                                #print(e) #debug only
                                print("Failed to execute command " + newlines + " in " + hostname)
                        file = hostname + '.txt'
                        for x in y:
                            to_doc(file, y)
                except Exception as e:
                    #print(e) #debug only
                    print("Cannot connect to " + hostname + " ip " + row[2])
                        
            elif (row[5] == "yes"):
                devices = {
                    'device_type': 'cisco_ios',
                    'ip': row[2],
                    'username': row[3],
                    'password': row[4],
                    'secret': row[6],
                    'fast_cli': False,
                }
                try:
                    net_connect = ConnectHandler(**devices)

                    hostname = row[1]

                    print("Processing " + hostname + " .......")
                    with open(sourcecmd, 'r') as file:
                        y = []
                        line = file.readlines()
                        for lines in line:
                            try:
                                send = net_connect.send_command(lines, delay_factor=2)
                                newlines = lines.strip('\n')
                                output = hostname + '# '+ lines + '\n' + send + '\n'
                                y.append(output)
                                print("Successfully execute command " + newlines + " in " + hostname)
                            except Exception as e:
                                #print(e) #debug only
                                print("Failed to execute command " + newlines + " in " + hostname)
                        file = hostname + '.txt'
                        for x in y:
                            to_doc(file, y)
                except Exception as e:
                    #print(e) #debug only
                    print("Cannot connect to " + hostname + " ip " + row[2])

        elif (row[0] == "telnet"):
            if (row[5] == "no"):
                devices = {
                    'device_type': 'cisco_ios_telnet',
                    'ip': row[2],
                    'username': row[3],
                    'password': row[4],
                    'fast_cli': False,
                }
                try:
                    net_connect = ConnectHandler(**devices)

                    hostname = row[1]

                    print("Processing " + hostname + " .......")
                    with open(sourcecmd, 'r') as file:
                        y = []
                        line = file.readlines()
                        for lines in line:
                            try:
                                send = net_connect.send_command(lines, delay_factor=2)
                                newlines = lines.strip('\n')
                                output = hostname + '# '+ lines + '\n' + send + '\n'
                                y.append(output)
                                print("Successfully execute command " + newlines + " in " + hostname)
                            except Exception as e:
                                #print(e) #debug only
                                print("Failed to execute command " + newlines + " in " + hostname)
                        file = hostname + '.txt'
                        for x in y:
                            to_doc(file, y)
                except Exception as e:
                    #print(e) #debug only
                    print("Cannot connect to " + hostname + " ip " + row[2])
                        
            elif (row[5] == "yes"):
                devices = {
                    'device_type': 'cisco_ios_telnet',
                    'ip': row[2],
                    'username': row[3],
                    'password': row[4],
                    'secret': row[6],
                    'fast_cli': False,
                }
                try:
                    net_connect = ConnectHandler(**devices)

                    hostname = row[1]

                    print("Processing " + hostname + " .......")
                    with open(sourcecmd, 'r') as file:
                        y = []
                        line = file.readlines()
                        for lines in line:
                            try:
                                send = net_connect.send_command(lines, delay_factor=2)
                                newlines = lines.strip('\n')
                                output = hostname + '# '+ lines + '\n' + send + '\n'
                                y.append(output)
                                print("Successfully execute command " + newlines + " in " + hostname)
                            except Exception as e:
                                #print(e) #debug only
                                print("Failed to execute command " + newlines + " in " + hostname)
                        file = hostname + '.txt'
                        for x in y:
                            to_doc(file, y)
                except Exception as e:
                    #print(e) #debug only
                    print("Cannot connect to " + hostname + " ip " + row[2])

            else:
                print("Status Enable Password belum ditentukan")
        else:
            print("Transport belum ditentukan")