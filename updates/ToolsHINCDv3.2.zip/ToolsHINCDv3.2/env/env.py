toolshincd = '3.2'
toolsfunction = 'Collect and Process Log'
def getVersion():
    return toolshincd

def functiontools():
    return toolsfunction