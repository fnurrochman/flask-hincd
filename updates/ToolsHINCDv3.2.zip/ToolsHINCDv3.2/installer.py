import sys
import os
import subprocess

currentFolder = os.path.abspath(os.path.dirname(__file__))
env_folder = os.path.abspath(os.path.join(currentFolder, "env"))
sys.path.insert(0, env_folder)

from env import getVersion

user_input = input('\nDo you want to install Tools HINCD version {} (yes/no): '.format(getVersion()))
if user_input.lower() == 'yes':
    print('\n')
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', 'requirement.txt'])

    message = '\nTools HINCD installed successfully. Version {}'.format(getVersion())
    print(message)
elif user_input.lower() == 'no':
    message = '\nFailed to install Tools HINCD version {}'.format(getVersion())
    print(message)
else:
    print('Type yes or no')